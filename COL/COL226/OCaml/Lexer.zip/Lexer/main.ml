open Printf
open Token

let get_token_list lexbuf =
  let rec work acc =
    match Lexer.token lexbuf with
    | EOF -> acc
    | t -> work (t::acc)
  in List.rev (work [])

let pp_token = function
  | Plus -> "PLUS"
  | Minus -> "MINUS"
  | Mul -> "MUL"
  | Slash -> "SLASH"
  | Integers(i) -> sprintf "INT %d" i
  | Bool(True) -> "BOOL TRUE"
  | Bool(False) -> "BOOL FALSE"
  | Assign -> "ASSIGN"
  | Or -> "OR"
  | And -> "AND"
  | Not -> "NOT"
  | Bang -> "BANG"
  | LessThan -> "LESSTHAN"
  | GreaterThan -> "GREATERTHAN"
  | Equal -> "EQUAL"
  | NotEqual -> "NOTEQUAL"
  | Comma -> "COMMA"
  | Semicolon -> "SEMICOLON"
  | LeftBracket -> "LEFTBRACKET"
  | RightBracket -> "RIGHTBRACKET"
  | LeftCurly -> "LEFTCURLY"
  | RightCurly -> "RIGHTCURLY"
  | Function -> "FUNCTION"
  | Let -> "LET"
  | If -> "IF"
  | Else -> "ELSE"
  | Return -> "RETURN"
  | Dot -> "DOT"
  | EOF -> "EOF"
  | Ident(i) -> sprintf "IDENT %s" i
  | Illegal -> "ILLEGAL"
;;

let lexer strings =
  let lexbuf = Lexing.from_string strings in
  let token_list = get_token_list lexbuf in
  List.map pp_token token_list |> List.iter (printf "%s\n")
;;

let read_file path = 
  let in_channel = open_in path in
  try
    while true do
      let line = input_line in_channel in
        lexer line
    done
  with End_of_file -> 
    close_in in_channel
  ;;

let main = 
  let f = "Code.txt" in
  read_file f
;;

