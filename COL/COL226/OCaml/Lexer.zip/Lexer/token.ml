type myBool = True | False
;;

type t = 
| Illegal
(* Identifiers *)
| Ident of string
| Integers of int
| Bool of myBool
(* Arith Operators *)
| Assign
| Plus
| Minus
| Mul
| Slash
(* Bool Operators *)
| Or
| And
| Not
(* Comparison Operators *)
| Bang
| LessThan
| GreaterThan
| Equal
| NotEqual
(* Delimiter *)
| Comma
| Semicolon
| LeftBracket
| RightBracket
| LeftCurly
| RightCurly
| Dot
(* Keywords *)
| Function
| Let
| If
| Else
| Return
(* EOF *)
| EOF
;;
